/**
 * 
 */
package org.apache.commons.mail;

/**
 * 
 */
public class EmailConcrete extends Email{
	@Override
	public Email setMsg(String msg) throws EmailException {
		return null;
	};

}
